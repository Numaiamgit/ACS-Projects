section .bss
    struc flight
        destination:      resb 32
        departingTime.day:     resb 1
        departingTime.hour:    resb 1
        departingTime.minutes: resb 1
        arrivingTime.day:      resb 1
        arrivingTime.hour:     resb 1
        arrivingTime.minutes:  resb 1
        bag_weight:            resb 2
        delayMinutes:          resb 1
        delayHours:            resb 1
    endstruc

section .text

;; DO NOT MODIFY
global sort_and_return

; int sort_and_return(struct flight* flights, int nrFlights,
;                      struct flight* bestFlight, char destination[32])
; rdi = flights (pointer)
; rsi = nrFlights (value)
; rdx = bestFlight (pointer to pre-allocated struct)
; rcx = destination (pointer to 32-byte string)
sort_and_return:
    push rbp
    mov rbp, rsp
    push rbx
    push r12
    push r13
    push r14
    push r15
    ;; DO NOT MODIFY
    ;; Your code starts here
    xor rax, rax
    xor r8, r8
    xor r9, r9
    xor r10, r10
    xor r11, r11
    xor rbx, rbx
    xor r12, r12
    for:
    mov rbx, r11
    ; dimensiunea unui struct flight in bytes
    imul rbx, 42
    movzx r8, byte [rdi + rbx + arrivingTime.day]
    movzx r9, byte [rdi + rbx + arrivingTime.hour]
    movzx r10, byte [rdi + rbx + arrivingTime.minutes]
    movzx rax, word [rdi + rbx + bag_weight]
    ; 42 = dimensiunea unui struct flight, offset spre urmatorul element
    cmp r8b, byte [rdi + rbx + 42 + arrivingTime.day]
    jl continua4
    jg sortare
    continua1:
    ; 42 = dimensiunea unui struct flight, offset spre urmatorul element
    cmp r9b, byte [rdi + rbx + 42 + arrivingTime.hour]
    jl continua4
    jg sortare
    continua2:
    ; 42 = dimensiunea unui struct flight, offset spre urmatorul element
    cmp r10b, byte [rdi + rbx + 42 + arrivingTime.minutes]
    jl continua4
    jg sortare
    continua3:
    ; 42 = dimensiunea unui struct flight, offset spre urmatorul element
    movzx r13, word [rdi + rbx + 42 + bag_weight]
    cmp rax, r13
    jge continua4
    sortare:
    mov r8, r11
    ; dimensiunea unui struct flight in bytes
    imul r8, 42
    ; rezervam 42 bytes pe stiva pentru swap temporar
    sub rsp, 42
    mov rbx, rsp

    mov rax, [rdi + r8]
    mov [rbx], rax
    ; copiem bytes 8-15
    mov rax, [rdi + r8 + 8]
    ; offset 8 in struct
    mov [rbx + 8], rax
    ; copiem bytes 16-23
    mov rax, [rdi + r8 + 16]
    ; offset 16 in struct
    mov [rbx + 16], rax
    ; copiem bytes 24-31
    mov rax, [rdi + r8 + 24]
    ; offset 24 in struct
    mov [rbx + 24], rax
    ; copiem bytes 32-39
    mov rax, [rdi + r8 + 32]
    ; offset 32 in struct
    mov [rbx + 32], rax
    ; copiem ultimii 2 bytes
    mov ax, word [rdi + r8 + 40]
    ; offset 40 in struct
    mov [rbx + 40], ax

    ; 42 = offset spre elementul j+1
    mov rax, [rdi + r8 + 42]
    mov [rdi + r8], rax
    ; offset 50 = 42 + 8
    mov rax, [rdi + r8 + 50]
    ; offset 8 in struct
    mov [rdi + r8 + 8], rax
    ; offset 58 = 42 + 16
    mov rax, [rdi + r8 + 58]
    ; offset 16 in struct
    mov [rdi + r8 + 16], rax
    ; offset 66 = 42 + 24
    mov rax, [rdi + r8 + 66]
    ; offset 24 in struct
    mov [rdi + r8 + 24], rax
    ; offset 74 = 42 + 32
    mov rax, [rdi + r8 + 74]
    ; offset 32 in struct
    mov [rdi + r8 + 32], rax
    ; offset 82 = 42 + 40
    mov ax, word [rdi + r8 + 82]
    ; offset 40 in struct
    mov [rdi + r8 + 40], ax

    mov rax, [rbx]
    ; offset 42 = inceputul elementului j+1
    mov [rdi + r8 + 42], rax
    ; offset 8 in struct
    mov rax, [rbx + 8]
    ; offset 50 = 42 + 8
    mov [rdi + r8 + 50], rax
    ; offset 16 in struct
    mov rax, [rbx + 16]
    ; offset 58 = 42 + 16
    mov [rdi + r8 + 58], rax
    ; offset 24 in struct
    mov rax, [rbx + 24]
    ; offset 66 = 42 + 24
    mov [rdi + r8 + 66], rax
    ; offset 32 in struct
    mov rax, [rbx + 32]
    ; offset 74 = 42 + 32
    mov [rdi + r8 + 74], rax
    ; offset 40 in struct
    mov ax, word [rbx + 40]
    ; offset 82 = 42 + 40
    mov [rdi + r8 + 82], ax

    ; eliberam cei 42 bytes rezervati pe stiva
    add rsp, 42

    continua4:
    inc r11
    mov rax, rsi
    dec rax
    sub rax, r12
    cmp r11, rax
    jl for
    inc r12
    xor r11, r11
    mov rax, rsi
    dec rax
    cmp r12, rax
    jl for
    xor r11, r11
    for2:
    mov rbx, r11
    ; dimensiunea unui struct flight in bytes
    imul rbx, 42

    mov r14, rdi
    mov r15, rsi
    mov r13, rcx
    lea rdi, [r14 + rbx + destination]
    mov rsi, r13
    ; comparam maxim 32 de bytes (dimensiunea campului destination)
    mov rcx, 32
    repe cmpsb
    mov rdi, r14
    mov rsi, r15
    mov rcx, r13

    je found
    inc r11
    cmp r11, r15
    jl for2
    jge end
    found:
    mov r8, r11
    ; dimensiunea unui struct flight in bytes
    imul r8, 42
    mov rbx, [rdi + r8]
    mov [rdx], rbx
    ; copiem bytes 8-15
    mov rbx, [rdi + r8 + 8]
    ; offset 8 in struct
    mov [rdx + 8], rbx
    ; copiem bytes 16-23
    mov rbx, [rdi + r8 + 16]
    ; offset 16 in struct
    mov [rdx + 16], rbx
    ; copiem bytes 24-31
    mov rbx, [rdi + r8 + 24]
    ; offset 24 in struct
    mov [rdx + 24], rbx
    ; copiem bytes 32-39
    mov rbx, [rdi + r8 + 32]
    ; offset 32 in struct
    mov [rdx + 32], rbx
    ; copiem ultimii 2 bytes
    mov bx, word [rdi + r8 + 40]
    ; offset 40 in struct
    mov [rdx + 40], bx
    ; returnam 1 daca am gasit zborul
    mov rax, 1
    jmp end2

    end:
    xor rax, rax

    end2:
    ;; Your code ends here
    ;; DO NOT MODIFY
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbx
    pop rbp
    ret
    ;; DO NOT MODIFY