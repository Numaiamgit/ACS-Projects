section .text

;; DO NOT MODIFY
global check_column
global check_row
global check_box

; int check_row(int **array, int size, int rowNr)
; rdi = int **array
; rsi = int size
; rdx = int rowNr
check_row:
    push rbp
    mov rbp, rsp
    push rbx
    push r12
    push r13
    push r14
    push r15
    ;; DO NOT MODIFY
    ;; Your code starts here
    xor r8, r8
    ; j incepe de la 1 (elementul de dupa i)
    mov r8, 1
    xor rcx, rcx
    xor rax, rax
    mov rcx, rdx
    mov r9, rsi
	; inmultim cu 4 pentru ca fiecare int ocupa 4 bytes
    imul r9, 4
    ; fiecare pointer de rand ocupa 8 bytes
    mov rax, [rdi + rdx * 8]
    xor rcx, rcx
    xor r10, r10
    xor r11, r11
    xor r12, r12
    xor r13, r13
    xor r14, r14
    mov r14, rsi
    inc r14
    imul r14, rsi
    for:
    ; fiecare int ocupa 4 bytes
    movsx rbx, dword [rax + rcx * 4]
    mov r12, rcx
    ; inmultim cu 4 pentru offset in bytes
    imul r12, 4
    mov r13, r8
    ; inmultim cu 4 pentru offset in bytes
    imul r13, 4
    add r12, r13
    ; citim elementul de comparat, 4 bytes per int
    movsx r15, dword [rax + r12]
    cmp rbx, r15
    je invalid
    inc r8
    cmp r8, rsi
    jl for
    for_preg:
    inc rcx
    mov r8, rcx
    inc r8
    cmp rcx, rsi
    jl for
    valid:
    ; returnam 1 daca nu am gasit duplicate
    mov rax, 1
    jmp end
    invalid:
    xor rax, rax
    end:
    ;; Your code ends here
    ;; DO NOT MODIFY
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbx
    pop rbp
    ret
    ;; DO NOT MODIFY

;; DO NOT MODIFY
; int check_column(int **array, int size, int columnNr)
; rdi = int **array
; rsi = int size
; rdx = int columnNr
check_column:
    push rbp
    mov rbp, rsp
    push rbx
    push r12
    push r13
    push r14
    push r15
    ;; DO NOT MODIFY
    ;; Your code starts here
    xor r8, r8
    ; j incepe de la 1
    mov r8, 1
    xor rcx, rcx
    xor rax, rax
    xor rcx, rcx
    ; j incepe de la 1 (randul de dupa i)
    mov r8, 1
    xor r10, r10
    xor r11, r11
    xor r14, r14
    mov r14, rsi
    inc r14
    imul r14, rsi
col_for1:
    ; fiecare pointer de rand ocupa 8 bytes
    mov rax, [rdi + rcx * 8]
    ; fiecare int ocupa 4 bytes
    movsx rbx, dword [rax + rdx * 4]
    ; fiecare pointer de rand ocupa 8 bytes
    mov r9, [rdi + r8 * 8]
    ; fiecare int ocupa 4 bytes
    movsx r10, dword [r9 + rdx * 4]
    cmp rbx, r10
    je invalid2
    inc r8
    cmp r8, rsi
    jl col_for1

col_for2:
col_for_preg:
    inc rcx
    mov r8, rcx
    inc r8
    cmp rcx, rsi
    jl col_for1
    valid2:
    ; returnam 1 daca nu am gasit duplicate
    mov rax, 1
    jmp end2
    invalid2:
    xor rax, rax
    end2:
    ;; Your code ends here
    ;; DO NOT MODIFY
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbx
    pop rbp
    ret
    ;; DO NOT MODIFY

;; DO NOT MODIFY
; int check_box(int **array, int size, int boxNr)
; rdi = int **array
; rsi = int size
; rdx = int boxNr
check_box:
    push rbp
    mov rbp, rsp
    push rbx
    push r12
    push r13
    push r14
    push r15
    ;; DO NOT MODIFY
    ;; Your code starts here
    xor r8, r8
    ; verificam daca tabloul este de dimensiune 4
    cmp rsi, 4
    jne cont_1
    ; radical din 4 este 2
    mov r9, 2
    cont_1:
    ; verificam daca tabloul este de dimensiune 9
    cmp rsi, 9
    jne cont_2
    ; radical din 9 este 3
    mov r9, 3
    cont_2:
    ; verificam daca tabloul este de dimensiune 16
    cmp rsi, 16
    jne cont3
    ; radical din 16 este 4
    mov r9, 4
    cont3:
    mov rax, rdx
    xor rdx, rdx
    div r9
    ; inmultim cu 1 pentru a copia valoarea in r12
    imul r12, rax, 1
    imul r12, r9
    ; inmultim cu 1 pentru a copia valoarea in r13
    imul r13, rdx, 1
    imul r13, r9

    xor r10, r10
    mov r8, r12
    for_box:
    mov rax, r12
    add rax, r9
    cmp r8, rax
    jge for_iar
    mov r11, r13
    cont4:
    mov rax, r13
    add rax, r9
    cmp r11, rax
    jge for_box_preg
    ; fiecare pointer de rand ocupa 8 bytes
    mov rax, [rdi + r8 * 8]
    ; fiecare int ocupa 4 bytes
    movsx rbx, dword [rax + r11 * 4]
    mov r15, r8
    mov r14, r11
    inc r14
    cont5:
    mov rax, r12
    add rax, r9
    cmp r15, rax
    jge cont6
    inner_col:
    mov rax, r13
    add rax, r9
    cmp r14, rax
    jge next_row
    ; fiecare pointer de rand ocupa 8 bytes
    mov rax, [rdi + r15 * 8]
    ; fiecare int ocupa 4 bytes
    movsx rcx, dword [rax + r14 * 4]
    cmp rbx, rcx
    je invalid3
    inc r14
    jmp inner_col
    next_row:
    mov r14, r13
    inc r15
    jmp cont5
    cont6:
    inc r11
    jmp cont4
    for_box_preg:
    inc r8
    jmp for_box
    for_iar:
    ; returnam 1 daca nu am gasit duplicate in box
    mov rax, 1
    jmp end_box
    cont7:
    count:
    cont_iar:
    invalid3:
    xor rax, rax
    end_box:
    ;; Your code ends here
    ;; DO NOT MODIFY
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbx
    pop rbp
    ret